#!/bin/bash
echo sharding execution context is $*